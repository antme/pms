package com.ragentek.api.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import com.ragentek.api.exception.ApiResponseCodeException;
import com.ragentek.api.util.status.ResponseCodeConstants;

public class ApiUtil {
	
	public static void main(String[] arg){
		System.out.println(isEmpty(1));
	}

    public static boolean limitKeyExists(String[] list, String checked) {

        if (list == null) {
            return true;
        }
        for (String value : list) {

            if (value.equals(checked)) {
                return true;
            }
        }

        return false;

    }

    
    public static boolean isEmpty(Object param) {

        if (param == null) {
            return true;
        }

        if (param instanceof Map) {
            return ((Map) param).isEmpty();
        }
        if (param instanceof List) {
            return ((List) param).isEmpty();
        }
        String parameter = param.toString();
        if (parameter.trim().length() == 0) {
            return true;
        }

        if ("null".equalsIgnoreCase(parameter)) {
            return true;
        }

        return false;
    }
 
    public static Integer getIntegerParam(Map<String, Object> params, String key, int defaultValue) {
        Object value = null;
        if (params != null){
            value = params.get(key);
        }
        Integer in = getInteger(value);
        in = (in == null) ? defaultValue : in;
        return in;
    }
    
    public static Integer getInteger(Map<String, Object> params, String key, int defaultValue) {
        Object value = null;
        if (params != null){
            value = params.get(key);
        }
        Integer in = null;
        if (value != null) {
            try {
            	in = Integer.valueOf(String.valueOf(value));
            } catch (Exception e) {
               return getInteger(value);
            }
        }
        in = (in == null) ? defaultValue : in;
        return in;
    }
    
    public static Integer getIntegerParam(Map<String, Object> params, String key) {
        Object value = null;
        if (params != null){
            value = params.get(key);
        } 
        return getInteger(value);
    }

    public  static Integer getInteger(Object value) {
        Integer result = null;

        if (value != null) {
            try {
                result = (int) Float.parseFloat(String.valueOf(value));
            } catch (NumberFormatException e) {
                try {
                    result = Integer.parseInt(String.valueOf(value));
                } catch (NumberFormatException e1) {
                    throw new ApiResponseCodeException(String.format("Integer parameter illegal [%s]", value),
                            ResponseCodeConstants.NUMBER_PARAMETER_ILLEGAL);
                }
            }

        }

        return result;
    }
    
    public static Long getLongParam(Map<String, Object> params, String key){
    	Long result = null;
    	if (params.get(key) != null){
    		try {
				result = Long.parseLong(String.valueOf(params.get(key)));
			} catch (NumberFormatException e) {
				throw new ApiResponseCodeException(String.format("Long type parameter illegal [%s]", params), 
						ResponseCodeConstants.NUMBER_PARAMETER_ILLEGAL);
			}
    	}
    	
    	return result;
    }
    
    
    public static boolean isIllegalGender(Object gender) {
        if (gender == null) {
            return false;
        }
        Integer userGender = getInteger(gender);
   
        if (userGender.equals(0) || userGender.equals(1)) {
            return true;
        }

        return false;

    }
    
    public static Float getFloatParam(Map<String, Object> params, String key){
    	Float result = null;
    	if (params.get(key) != null){
    		try {
				result = Float.parseFloat(String.valueOf(params.get(key)));
			} catch (NumberFormatException e) {
				throw new ApiResponseCodeException(String.format("Float type parameter illegal [%s]", params), 
						ResponseCodeConstants.NUMBER_PARAMETER_ILLEGAL);
			}
    	}
    	
    	return result;
    }
    
    public static Integer getRandomIntByCap(int cap){
    	Random random = new Random();
    	int num = random.nextInt(cap);
    	if (num == 0){
    		num++;
    	}
    	return num;
    }
    
    public static Map<String, String> sortLinkMap(Map<String, String> map){
        ArrayList<Entry<String,String>> list = new ArrayList<Entry<String,String>>(map.entrySet());   
          
        Collections.sort(list, new Comparator<Object>(){
            public int compare(Object e1, Object e2){   
                int v1 = Integer.parseInt(((Entry<String,String>)e1).getValue().toString());   
                int v2 = Integer.parseInt(((Entry)e2).getValue().toString());   
                return v1-v2;   
            }   
        });   
        
        Map<String, String> sortResult = new LinkedHashMap<String, String>();
        for (Entry<String,String> e : list){
            if (Integer.parseInt(e.getValue()) > 0)
                sortResult.put(e.getKey(), e.getValue());
        }
        
        return sortResult;
    }
    
    
    public static String connectValueWithMapList(List<Map<String, Object>> data, String key, String split) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < data.size(); i++) {
            String name = (String) data.get(i).get(key);
            if (i == 0) {
                sb.append(name);
            } else {
                sb.append(split).append(name);
            }
        }

        return sb.toString();
    }
    
    public static String connectValueWithObjectList(List<Object> data, String key, String split) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < data.size(); i++) {
            Map<String, Object> map = (Map<String, Object>)data.get(i);
            String name = (String) map.get(key);
            if (i == 0) {
                sb.append(name);
            } else {
                sb.append(split).append(name);
            }
        }

        return sb.toString();
    }

    
    public static List<String> getMongoIds(Map<String, Object> listResult) {
        List<Map<String, Object>> allIds = (List<Map<String, Object>>) listResult.get(ApiConstants.RESULTS_DATA);
        List<String> ids = new ArrayList<String>();
        for (Map map : allIds) {
            ids.add(map.get(ApiConstants.MONGO_ID).toString());
        }
        return ids;
    }
    
    
    public static Map<String, Object> getYearsAndConstellation(Long birth) throws ParseException {
        Map<String, Object> map = new HashMap<String, Object>();
        int[] cons = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
        int[] consEdgeDay = { 21, 20, 21, 21, 22, 22, 23, 23, 24, 24, 23, 22 };
        Calendar c = Calendar.getInstance();
        c.setTime(DateUtil.getDate(birth));
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        if (day < consEdgeDay[month]) {
            month = month - 1;
        }
        if (month >= 0) {
            map.put(ApiConstants.USER_CONSTELLATION, cons[month]);
        } else {
            map.put(ApiConstants.USER_CONSTELLATION, cons[11]);
        }

        if (year >= 1960 && year <= 1969) {
            map.put(ApiConstants.USER_YEARS, ApiConstants.YEARS_60);
        } else if (year >= 1970 && year <= 1979) {
            map.put(ApiConstants.USER_YEARS, ApiConstants.YEARS_70);
        } else if (year >= 1980 && year <= 1989) {
            map.put(ApiConstants.USER_YEARS, ApiConstants.YEARS_80);
        } else if (year >= 1990 && year <= 1999) {
            map.put(ApiConstants.USER_YEARS, ApiConstants.YEARS_90);
        } else if (year >= 2000) {
            map.put(ApiConstants.USER_YEARS, ApiConstants.YEARS_00);
        } else {
            map.put(ApiConstants.USER_YEARS, ApiConstants.YEARS_OLD);
        }

        return map;
    }
    
    public static String getGenderName(Integer gender){
    	if(gender != null && gender == 1){
    		return "她";
    	} else {
    		return "他";
    	}
    }
    public static void mergeMongoResult(Map<String, Object> result, Map<String, Object> addResult){
        List<Map<String, Object>> list = (List<Map<String, Object>>)result.get(ApiConstants.RESULTS_DATA);
        List<Map<String, Object>> listAdd = (List<Map<String, Object>>)addResult.get(ApiConstants.RESULTS_DATA);
        list.addAll(listAdd);
    }
    
    
    public static String formateDate(Date date, String patten) {
        SimpleDateFormat format = new SimpleDateFormat(patten);
        return format.format(date);

    }

}
