package com.ragentek.api.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.mongodb.BasicDBObject;

public class JsonMapConverterUtil {

    /**
     * 
     * Convert a json string to a JAVA Map Object
     * 
     * @param json
     * @return
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> toMap(String json) throws JsonSyntaxException {
        return new Gson().fromJson(json, HashMap.class);
    }

    /**
     * Convert JAVA Map Object to JSON, the Object can be anything: string, int,
     * map etc
     * 
     * @param map
     * @return
     */
    public static String toJson(Map<String, Object> map) {
        BasicDBObject doc = new BasicDBObject(map);
        return doc.toString();
    }

    /**
     * Convert a MAP list to JSON string
     * 
     * @param key
     * @param mapList
     * @return
     */
    public static String toJson(String key, List<Map<String, Object>> mapList) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(key, mapList);

        return JsonMapConverterUtil.toJson(map);
    }

}
