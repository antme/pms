package com.ragentek.api.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ragentek.api.service.AbstractService;
import com.ragentek.api.service.IGroupService;
import com.ragentek.api.service.IUserService;

public class GroupServiceImpl extends AbstractService implements IGroupService {

    private static Logger logger = LogManager.getLogger(GroupServiceImpl.class);
    
    private IUserService userService;
    
    
    

    @Override
    public String geValidatorFileName() {
        return "group";
    }

  
}
