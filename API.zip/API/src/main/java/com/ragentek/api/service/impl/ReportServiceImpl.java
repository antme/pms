package com.ragentek.api.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ragentek.api.service.AbstractService;
import com.ragentek.api.service.IReportService;

public class ReportServiceImpl extends AbstractService implements IReportService  {
	
	private static final Logger logger = LogManager.getLogger(ReportServiceImpl.class);

	@Override
	public String geValidatorFileName() {
		return null;
	}
	

	
}
