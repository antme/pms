package com.ragentek.api.annotation;

import java.lang.annotation.Annotation;

public @interface RoleValidate{

	String id();

	String name();

}
