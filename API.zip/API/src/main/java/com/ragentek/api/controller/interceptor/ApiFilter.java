package com.ragentek.api.controller.interceptor;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.util.NestedServletException;

import com.ragentek.api.controller.AbstractController;
import com.ragentek.api.exception.ApiResponseCodeException;

public class ApiFilter extends AbstractController implements Filter {

    @Override
    public void destroy() {

    }

    private static Logger logger = LogManager.getLogger(ApiFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {

        boolean success = false;
        try {
            filterChain.doFilter(request, response);
            success = true;
        } catch (Exception e) {

            if (e instanceof NestedServletException) {
                Throwable t = e.getCause();

                if (t instanceof ApiResponseCodeException) {
                    //do nothing
                } else {
                    logger.fatal("Fatal error when user try to call API ", e);
                }
            } else {
                logger.fatal("Fatal error when user try to call API ", e);
            }
            returnServerError(e.getCause(), (HttpServletResponse) response);
        }



    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {

    }

}
