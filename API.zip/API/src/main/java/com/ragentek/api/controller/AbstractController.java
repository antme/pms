package com.ragentek.api.controller;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.ragentek.api.cfg.ConfigurationManager;
import com.ragentek.api.exception.ApiResponseCodeException;
import com.ragentek.api.util.ApiConstants;
import com.ragentek.api.util.ApiThreadLocal;
import com.ragentek.api.util.ApiUtil;
import com.ragentek.api.util.DataEncrypt;
import com.ragentek.api.util.status.ResponseCodeConstants;
import com.ragentek.api.util.status.ResponseStatus;

public abstract class AbstractController {
    private static Logger logger = LogManager.getLogger(AbstractController.class);

    public HashMap<String, Object> parserJsonParameters(HttpServletRequest request, String parameterConfig, boolean decrypt, boolean emptyParameter) {
        return parserJsonParameters(request, decrypt, emptyParameter, true);
    }

    public HashMap<String, Object> parserJsonParameters(HttpServletRequest request, boolean decrypt, boolean emptyParameter, boolean checkPermisson) {
        HashMap<String, Object> parametersMap = buildParameters(request, decrypt, emptyParameter);
        getRequestHeaders(request, parametersMap);
        logger.debug(String.format("--------------Client post parameters for path [%s] is [%s]", request.getPathInfo(), new JSONObject(parametersMap).toString()));

        if (checkPermisson) {
            checkRequestPermissions(request, parametersMap);
        } 
      
        request.setAttribute("apiParameters", parametersMap);
        return parametersMap;
    }

    @SuppressWarnings("unchecked")
	private HashMap<String, Object> buildParameters(HttpServletRequest request, boolean decrypt, boolean emptyParameter) {
        HashMap<String, Object> parametersMap = new HashMap<String, Object>();

        String parameters = request.getParameter(ApiConstants.JSON_PARAMETERS_LABEL);
        if (parameters != null) {

            if (decrypt) {
                try {
                    // if is json, not encrypt
                    new JSONObject(parameters);
                } catch (JSONException e) {
                    parameters = DataEncrypt.decrypt(parameters, ConfigurationManager.getEncryptKey());
                }
            }

            if (parameters != null) {   
            	try{
                    parametersMap = new Gson().fromJson(parameters, HashMap.class);  
            	}catch(JsonSyntaxException e){
            		//TODO
            	}

            }
        } else {
            Enumeration<?> parameterNames = request.getParameterNames();
            while (parameterNames.hasMoreElements()) {
                String pName = parameterNames.nextElement().toString();
                if (!(pName.equalsIgnoreCase(ApiConstants.CHENG_GAME_ACCOUNT_ID) || pName.equalsIgnoreCase(ApiConstants.CHENG_GAME_MOBILE_ID))) {
                    parametersMap.put(pName, request.getParameter(pName));
                }
            }
        }

        if (!emptyParameter && (parametersMap == null || parametersMap.isEmpty())) {
            throw new ApiResponseCodeException(String.format("Parameters required for path [%s]", request.getPathInfo()), ResponseCodeConstants.PARAMETERS_EMPTY.toString());
        }

        return parametersMap;
    }


    private void checkRequestPermissions(HttpServletRequest request, HashMap<String, Object> parametersMap) {
        


    }

    private void getRequestHeaders(HttpServletRequest request, HashMap<String, Object> parametersMap) {

        String chengYouId = request.getHeader(ApiConstants.CHENG_GAME_MOBILE_ID) == null ? request.getParameter(ApiConstants.CHENG_GAME_MOBILE_ID) : request
                .getHeader(ApiConstants.CHENG_GAME_MOBILE_ID);
        String accountId = request.getHeader(ApiConstants.CHENG_GAME_ACCOUNT_ID) == null ? request.getParameter(ApiConstants.CHENG_GAME_ACCOUNT_ID) : request
                .getHeader(ApiConstants.CHENG_GAME_ACCOUNT_ID);
        String channelId = request.getHeader(ApiConstants.CHANNEL_ID) == null ? request.getParameter(ApiConstants.CHANNEL_ID) : request.getHeader(ApiConstants.CHANNEL_ID);
 
        String token = request.getHeader("token") == null ? request.getParameter("token") : request.getHeader("token");
        String clientName = request.getHeader(ApiConstants.CLIENT_NAME) == null ? request.getParameter(ApiConstants.CLIENT_NAME) : request.getHeader(ApiConstants.CLIENT_NAME);
        
        chengYouId = "null".equalsIgnoreCase(chengYouId) ? null : chengYouId;
        accountId = "null".equalsIgnoreCase(accountId) ? null : accountId;
        channelId = "null".equalsIgnoreCase(channelId) ? null : channelId;
        clientName = "null".equalsIgnoreCase(clientName) ? null : clientName;
        
        if (clientName == null) {
            //old Yulor client
            channelId = ApiConstants.YULOR_CHANNEL_ID;
        }

        
        if (clientName != null && clientName.equalsIgnoreCase(String.valueOf(ApiConstants.CLIENT_QINGCHENG_APPSTORE))) {

            // TODO: deal with qingcheng
            clientName = String.valueOf(ApiConstants.CLIENT_YULOR);
            channelId = ApiConstants.YULOR_CHANNEL_ID;
        }
            
            
        //从json_p parameters中获取channelId
        if (ApiUtil.isEmpty(channelId)){
        	channelId = (String)parametersMap.get(ApiConstants.CHANNEL_ID);
        }
        
        if (!ApiUtil.isEmpty(channelId)) {
            parametersMap.put(ApiConstants.CHANNEL_ID, channelId);
            ApiThreadLocal.set(ApiConstants.CHANNEL_ID, channelId);
        }
        if (!ApiUtil.isEmpty(clientName)) {
            parametersMap.put(ApiConstants.CLIENT_NAME, Integer.parseInt(clientName));
        } else {
            parametersMap.put(ApiConstants.CLIENT_NAME, ApiConstants.CLIENT_YULOR);
        }
        ApiThreadLocal.set(ApiConstants.CLIENT_NAME, parametersMap.get(ApiConstants.CLIENT_NAME));
        
        if (!ApiUtil.isEmpty(chengYouId)) {
            parametersMap.put(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID, chengYouId);
        }
        if (!ApiUtil.isEmpty(accountId)) {
            parametersMap.put(ApiConstants.CHENG_GAME_ACCOUNT_ANALYSIS_ID, accountId);
        }
        
        if (!ApiUtil.isEmpty(token)) {
            parametersMap.put("token", token);
        }

    }

    protected void responseSuccess(Map<String, Object> data, String dataKey, HttpServletResponse response) {
        responseMsg(data, dataKey, ResponseStatus.SUCCESS, response);
    }

    protected void responseSuccessWithKey(String key, String value, HttpServletResponse response) {
        if (key == null) {
            responseSuccess(null, null, response);
        } else {
            Map<String, Object> temp = new HashMap<String, Object>();
            temp.put(key, value);
            responseSuccess(temp, null, response);
        }
    }

    protected void responseFail(Map<String, Object> data, String dataKey, HttpServletResponse response) {

        responseMsg(data, dataKey, ResponseStatus.FAIL, response);
    }

    /**
     * This function will return JSON data to Client
     * 
     * 
     * @param data
     *            data to return to client
     * @param dataKey
     *            if set dataKey, the JSON format use dataKey as the JSON key,
     *            data as it's value, and both the dataKey and "status" key are
     *            child of the JSON root node. If not set dataKey, the data and
     *            the "status" node are both the child of the JSON root node
     * @param status
     *            0:FAIL, 1: SUCCESS
     * @return
     */
    private void responseMsg(Map<String, Object> data, String dataKey, ResponseStatus status, HttpServletResponse response) {

        Map<String, Object> result = new HashMap<String, Object>();

        if (data != null) {
            if (dataKey == null) {
                data.put("status", status.toString());
                result = data;
            } else {
                result.put(dataKey, data);
                result.put("status", status.toString());
            }
        } else {
            result.put("status", status.toString());
        }

        response.setContentType("text/plain;charset=UTF-8");
        response.addHeader("Accept-Encoding", "gzip, deflate");
        try {
            response.getWriter().write(new JSONObject(result).toString());
        } catch (IOException e) {
            logger.fatal("Write response data to client failed!", e);
        }
        ApiThreadLocal.removeAll();

    }

    protected void responseString(String data, HttpServletResponse response) {
        response.setContentType("text/plain;charset=UTF-8");
        try {
            response.getWriter().println(data);
        } catch (IOException e) {
            logger.fatal("Write response data to client failed!", e);
        }
        ApiThreadLocal.removeAll();

    }

    protected void returnServerError(Throwable throwable, HttpServletResponse response) {
        Map<String, Object> temp = new HashMap<String, Object>();

        if (throwable instanceof ApiResponseCodeException) {
            ApiResponseCodeException apiException = (ApiResponseCodeException) throwable;
            temp.put("msg", apiException.getTipMsg());
            logger.error(String.format(" =========== API Validation failed with tip msg [%s] and log msg [%s] ", apiException.getTipMsg(), apiException.getMessage()));

        } else {
            temp.put(ApiConstants.CODE, ResponseCodeConstants.SERVER_ERROR.toString());
            temp.put("msg", "System Error");
        }
        responseMsg(temp, null, ResponseStatus.FAIL, response);

    }

}
