package com.ragentek.api.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ragentek.api.service.IUserService;
import com.ragentek.api.util.ApiConstants;

@Controller
@RequestMapping("/user")
public class UserController extends AbstractController {
    private IUserService userService = null;

    private static Logger logger = LogManager.getLogger(UserController.class);


    @RequestMapping("/register")
    public void register(HttpServletRequest request, HttpServletResponse response) {
        Map<String, Object> user = parserJsonParameters(request, false, false, false);
        responseSuccessWithKey(ApiConstants.MONGO_ID, userService.register(user), response);
    }

    /**
     * Both client and backend will call this API
     * 
     * @param request
     * @param response
     */
    @RequestMapping("/info/edit")
    public void update(HttpServletRequest request, HttpServletResponse response) {
        userService.updateUserInfo(this.parserJsonParameters(request, null, false, false));
        responseSuccess(null, null, response);
    }

    @RequestMapping("/login")
    public void login(HttpServletRequest request, HttpServletResponse response) {
        responseSuccessWithKey(ApiConstants.MONGO_ID, userService.login(parserJsonParameters(request, null, false, false)), response);
    }


    @RequestMapping("/logout")
    public void logout(HttpServletRequest request, HttpServletResponse response) {
        responseSuccessWithKey(ApiConstants.MONGO_ID, userService.logout(parserJsonParameters(request, null, false, true)), response);
    }


    public IUserService getUserService() {
        return userService;
    }

    public void setUserService(IUserService userService) {
        this.userService = userService;
    }

}
