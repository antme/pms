package com.ragentek.api.exception;

import com.ragentek.api.cfg.ConfigurationManager;

public class ApiResponseCodeException extends RuntimeException {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;


    private Object tipMsg;

    /**
     * Constructs an <code>ApiApiIllegalArgumentException</code> with no detail
     * message.
     */
    @SuppressWarnings("unused")
    private ApiResponseCodeException() {
        super();
    }

    /**
     * Constructs an <code>ApiApiIllegalArgumentException</code> with the
     * specified detail message.
     * 
     * @param s
     *            the detail message.
     */
    public ApiResponseCodeException(String logMsg, Object tipKey) {
        super(logMsg);
        this.tipMsg = ConfigurationManager.getSystemMessage(tipKey.toString());
    }
    
    public ApiResponseCodeException(String logMsg, Object tipKey, Object convertedMsg) {
        super(logMsg);
        this.tipMsg = convertedMsg;
    }

    public Object getTipMsg() {
        return tipMsg;
    }

    public void setTipMsg(Object tipMsg) {
        this.tipMsg = tipMsg;
    }

}
