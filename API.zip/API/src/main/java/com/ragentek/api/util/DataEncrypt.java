package com.ragentek.api.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DataEncrypt {

    private final static Base64 base64encoder = new Base64();
    private final static String encoding = "UTF-8";

    private final static Logger logger = LogManager.getLogger(DataEncrypt.class);

    /**
     * 加密字符串
     * 
     */
    public static String encrypt(String encodeStr, String encryptKey) {
        if (encodeStr != null && encodeStr.length() > 0) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try {
                int mode = Cipher.ENCRYPT_MODE;
                SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
                byte[] keyData = encryptKey.getBytes();
                DESKeySpec keySpec = new DESKeySpec(keyData);
                SecretKey key = keyFactory.generateSecret(keySpec);
                Cipher cipher = Cipher.getInstance("DES");
                cipher.init(mode, key);
                return base64encoder.encodeToString(cipher.doFinal(((String) encodeStr).getBytes(encoding)));
            } catch (Exception e) {
                logger.error(String.format("Encrypt data:[ %s ] error", encodeStr), e);
            } finally {
                try {
                    baos.close();
                } catch (IOException e) {
                    logger.error(String.format("Close ByteArrayOutputStream error after encrypt [ %s ]", encodeStr), e);
                }
            }

        }
        return null;
    }

    /**
     * 解密字符串
     */
    public static String decrypt(String decodeStr, String decryptKey) {
        if (decodeStr != null && decodeStr.length() > 0) {

            byte[] encodeByte = base64encoder.decode(decodeStr);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try {
                int mode = Cipher.DECRYPT_MODE;
                SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
                byte[] keyData = decryptKey.getBytes();
                DESKeySpec keySpec = new DESKeySpec(keyData);
                SecretKey key = keyFactory.generateSecret(keySpec);
                Cipher cipher = Cipher.getInstance("DES");
                cipher.init(mode, key);

                return new String(cipher.doFinal(encodeByte), encoding);
            } catch (Exception e) {
                logger.error(String.format("Decrypt data:[ %s ] error", decodeStr), e);
            } finally {
                try {
                    baos.close();
                } catch (IOException e) {
                    logger.error(String.format("Close ByteArrayOutputStream error after decrypt [ %s ]", decodeStr), e);
                }
            }

        }
        return null;
    }

}
