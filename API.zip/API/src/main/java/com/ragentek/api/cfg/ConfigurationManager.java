package com.ragentek.api.cfg;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ragentek.api.util.ApiConstants;

public class ConfigurationManager {

    public static final String DB_NAME = "dbName";

    private static Logger logger = LogManager.getLogger(ConfigurationManager.class);

    private static Properties properties = new Properties();

    public static void setConfiguraion(String configFile) {

        if (properties.isEmpty()) {

            try {
                // load resource from class root path
                properties.load(ConfigurationManager.class.getResourceAsStream("/default.properties"));
            } catch (IOException e) {
                logger.fatal("Load property file failed: ".concat(configFile), e);
            }

            try {
                // load resource from class root path
                properties.load(ConfigurationManager.class.getResourceAsStream("/".concat(configFile)));
            } catch (IOException e) {
                logger.fatal("Load property file failed: ".concat(configFile), e);
            }

            try {
                properties.load(ConfigurationManager.class.getResourceAsStream("/validators/applicationResources.properties"));
            } catch (IOException e) {
                logger.fatal("Load property file failed: ".concat("/validators/applicationResources.properties"), e);
            }

            try {
                properties.load(ConfigurationManager.class.getResourceAsStream("/points.properties"));
            } catch (IOException e) {
                logger.fatal("Load property file failed: ".concat("/points.properties"), e);
            }

        }
    }

    public static String getImgServerUrl() {
        return properties.getProperty(ApiConstants.IMG_SERVER_URL);
    }

    public static String getApkServerUrl() {
        return properties.getProperty(ApiConstants.APK_SERVER_URL);
    }

    public static String getApiServerUrl() {
        return properties.getProperty(ApiConstants.API_SERVER_URL);
    }

    public static String getPushServerUrl() {
        return properties.getProperty(ApiConstants.PUSH_SERVER_URL);
    }
    
    public static String getPushKey() {
        return properties.getProperty("pushKey");
    }
    
    public static String getEncryptKey() {
        return properties.getProperty(ApiConstants.ENCRYPT_KEY);
    }

    public static String getCategoryDefaultImg() {
        return properties.getProperty(ApiConstants.APP_CATEGORY_DEFAULT_IMAGE_URL);
    }

    public static String getCategoryDefaultPriority() {
        return properties.getProperty(ApiConstants.APP_CATEGORY_DEFAULT_PRIORITY);
    }

    public static String getUserDefaultLogoM() {
        return properties.getProperty(ApiConstants.USER_LOGO_DEFAULT_M);
    }

    public static String getUserDefaultLogoF() {
        return properties.getProperty(ApiConstants.USER_LOGO_DEFAULT_F);
    }

    public static String getUserDefaultNickName(int gender) {
    	String key = ApiConstants.USER_NICK_NAME_DEFAULT;
    	if(gender == 0) {
    		key = ApiConstants.USER_NICK_NAME_DEFAULT_M;
    	} else if(gender == 1) {
    		key = ApiConstants.USER_NICK_NAME_DEFAULT_F;
    	}
        try {
            return new String(properties.getProperty(key).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }

    public static String getTmpFolder() {
        return properties.getProperty(ApiConstants.TMP_FOLDER);
    }

    public static String getDefaultDeveloper() {
        return properties.getProperty(ApiConstants.APP_DEVELOPER);
    }

    public static Integer getDefaultScore() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.SCORE)));
    }

    public static Integer getCostForCreateGroup() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.GROUP_CREATE_COST_POINT)));
    }

    public static Float getDefaultAdminScore() {
        return Float.parseFloat(String.valueOf(properties.getProperty(ApiConstants.APP_ADMIN_SCORE)));
    }

    public static String getDefaultAdminComment() {
        return properties.getProperty(ApiConstants.APP_ADMIN_COMMENT);
    }

    public static String getGroupMilestoneCreate() {
        try {
            return new String(properties.getProperty(ApiConstants.GROUP_MILESTONE_CREATE).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }

    public static String getGroupMilestoneStationApp() {
        try {
            return new String(properties.getProperty(ApiConstants.GROUP_MILESTONE_STATION_APP).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }

    public static Integer getDefaultStartUpSpeed() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.APP_START_UP_SPEED)));
    }

    public static Integer getScoreNums() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.APP_SCORE_NUMS)));
    }

    public static Integer getDownloadBase() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.APP_TOTAL_DOWNLOAD_BASE)));
    }

    public static String getActivityImage() {
        return properties.getProperty(ApiConstants.APP_ACTIVITY_IMAGE);
    }

    public static Integer getActivityPriority() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.APP_ACTIVITY_PRIORITY)));
    }

    public static String getCommendationImage() {
        return properties.getProperty(ApiConstants.APP_COMMENDATION_IMAGE);
    }

    public static String getUserDefaultBirthDay() {
        return properties.getProperty(ApiConstants.USER_DEFAULT_BIRTH_DAY);
    }

    public static String getYuleAdminId() {
        return properties.getProperty(ApiConstants.YULE_ADMIN_ID);
    }

    public static Integer getCommendationPriority() {
        return Integer.parseInt(String.valueOf(properties.getProperty(ApiConstants.APP_COMMENDATION_PRIORITY)));
    }

    public static String getDbName() {
        return properties.getProperty(DB_NAME);
    }

    public static String getSystemMessage(String type) {

        if (properties.getProperty(type) != null) {
            try {
                return new String(properties.getProperty(type).getBytes("ISO-8859-1"), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                // do nothing
            }
        } else {

            return String.format("please configure the error message [%s] in applicationResources.properties", type);
        }
        return null;
    }

    public static Integer getGameStoryUpScore() {
        return Integer.parseInt(String.valueOf(properties.getProperty("gameStoryUpScore")));
    }

    public static Integer getGameStoryDownScore() {
        return Integer.parseInt(String.valueOf(properties.getProperty("gameStoryDownScore")));
    }

    public static String getPointsConfig(String path) {

        return properties.getProperty(path);
    }

    public static void setProperties(String key, String value) {
        properties.setProperty(key, value);
    }
    
    public static String getUserLevelName(int level) {
        try {
            return new String(properties.getProperty("lv".concat(String.valueOf(level))).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }
    
    public static String getHomePageDailyGuideFirstLogin() {
        try {
            return new String(properties.getProperty(ApiConstants.HOME_TOP_DAILY_GUIDE_FIRST_LOGIN_CONTENT).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }
    
    public static String getHomePageDailyGuideJoinGroup() {
        try {
            return new String(properties.getProperty(ApiConstants.HOME_TOP_DAILY_GUIDE_JOIN_GROUP_CONTENT).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }
    
    public static String getHomePageDailyGuideRewardBox() {
        try {
            return new String(properties.getProperty(ApiConstants.HOME_TOP_DAILY_GUIDE_REWARD_BOX_CONTENT).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }
    
    public static String getHomePageDailyGuideUserFollow() {
        try {
            return new String(properties.getProperty(ApiConstants.HOME_TOP_DAILY_GUIDE_USER_FOLLOW_CONTENT).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }
    
    public static String getSystemUserLogo() {
        return properties.getProperty(ApiConstants.SYSTEM_USER_DEFAULT_LOGO);
    }
    
    public static String getSystemUserName() {
        try {
            return new String(properties.getProperty(ApiConstants.SYSTEM_USER_NAME).getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            // do nothing
        }
        return null;
    }

    public static Integer getDailyRewardBoxFloor() {
        return Integer.parseInt(String.valueOf(properties.getProperty("dailyRewardBoxFloor")));
    }

    public static Integer getDailyRewardBoxCeiling() {
        return Integer.parseInt(String.valueOf(properties.getProperty("dailyRewardBoxCeiling")));
    }

}
