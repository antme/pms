package com.ragentek.api.util;

public class ApiConstants {

    public static final String DB_NAME = "ragentek";

    public static final String CHENG_GAME_MOBILE_ID = "chengyouID";
    public static final String CHENG_GAME_ACCOUNT_ID = "accountID";
    public static final String IGNORE_CHANNEL_ID_QUERY = "ignore_channel_id_query";
    public static final String IGNORE_CLIENT_NAME_QUERY = "ignore_client_name_query";
    
    public static final String CHANNEL_ID = "channelId";
    //TODO: should delete,currently Yulor client use channelID,not channelId
    public static final String CHANNEL_ID_YULOR_OLD = "channelID";
    public static final String YULOR_CHANNEL_ID = "Yulor";
    public static final String CHANNEL_TYPE = "channelType";
    // do not use the key when you need save data into database
    public static final String CHENG_GAME_ACCOUNT_ANALYSIS_ID = "accountID_analysis";
    // do not use the key when you need save data into database
    public static final String CHENG_GAME_MOBILE_ANALYSIS_ID = "chengyouID_analysis";
    public static final String CHENG_GAME_BEHAVIOR_ANALYSYS_DATA = "behaviorAnalysisData";
    public static final String CHENG_GAME_BEHAVIOR_TYPE = "behaviorType";
    public static final String CHENG_GAME_BEHAVIOR_PATH = "requestPath";
    public static final String MONGO_ID = "_id";
    public static final String IDS = "ids";
    public static final String CREATED_ON = "createdOn";
    public static final String UPDATED_ON = "updatedOn";
    public static final String KEYWORD = "keyword";
    public static final String KEYWORD_SEARCH_COUNT = "searchCOunt";
    public static final String IMG_SERVER_URL = "imgServerUrl";
    public static final String APK_SERVER_URL = "APKServerUrl";
    public static final String API_SERVER_URL = "APIServerUrl";
    public static final String ENCRYPT_KEY = "encryptKey";
    public static final String TMP_FOLDER = "tempFolder";
    public static final String PATH_INFO = "pathInfo";
    public static final String IP_ADDRESS = "ipAddress";
    public static final String USER_AGENT = "user-agent";
    public static final String SCREEN_SIZE = "screenSize";


    public static final String MOBILE_INFO_UPLOAD_LABEL = "phoneInfos";
    public static final String IMEI_LABEL = "imei";
    public static final String UUID_LABEL = "uuid";
    public static final String WIFI_MAC_LABEL = "wifiMac";
    public static final String BLUETOOTH_MAC = "BTMac";
    
    public static final String STATUS = "status";
    public static final String FROM_ADMIN_SERVER = "fromAdmin";
    public static final String ADMIN_VIEW_USER_NAEM = "viewName";
    
    //Commons
    public static final String GAMER_AMOUNT = "gamerAmount";
    public static final String POINT = "point";
    public static final String AMOUNT = "amount";
    public static final String YULE_ADMIN_ID = "yuleAdminId";

    // App category
    public static final String APP_CATEGORY_NAME = "appCategoryName";
    public static final String APP_CATEGORY_IMAGE_URL = "imageUrl";
    public static final String APP_CATEGORY_PRIORITY = "priority";
    public static final String APP_CATEGORY_ID = "categoryId";
    public static final String APP_CATEGORY_DEFAULT_IMAGE_URL = "categoryDefaultImg";
    public static final String APP_CATEGORY_DEFAULT_PRIORITY = "categoryDefaultPriority";
    public static final String APP_CATEGORY_BIND_TO = "bindto";
    public static final String APP_CATEGORY_GOOD_APPS = "goodApps";
    
    public static final String ALL_CATEGORY_BASE_DATA = "baseCategory";

    // UserTag
    public static final String USER_TAG_NAME = "userTagName";
    public static final String USER_TAG_ID = "userTagId";
    public static final String USER_TAG_IDS = "userTagIds";
    public static final String USER_TAG_CATEGORY = "category";
    public static final String USER_TAG_CATEGORY_MALE = "0";
    public static final String USER_TAG_CATEGORY_FEMAL = "1";
    public static final String USER_TAG_CATEGORY_ALL = "2";
    public static final String USER_TAG_CATEGORY_RANDOM = "3";

    public static final String APP_ID = "appId";
    public static final String APP_IDS = "appIds";

    // db collections
    public static final String DB_APP_COLLECTION_NAME = "app";
    public static final String DB_YULE_CLIENT_COLLECTION_NAME = "yuleClient";
    public static final String DB_MOBILE_COLLECTION_NAME = "mobile";
    public static final String DB_APP_CATEGORY_COLLECTION_NAME = "appCategory";
    public static final String DB_USER_COLLECTION_NAME = "user";
    public static final String DB_USER_TAG_COLLECTION_NAME = "userTag";
    public static final String DB_USER_PRAISE_COLLECTION = "userPraise";
    public static final String DB_POST_PRAISE_COLLECTION = "postPraise";
    public static final String DB_FOLLOW_COLLECTION_NAME = "follow";
    public static final String DB_VISITOR_COLLECTION_NAME = "visitor";
    public static final String DB_BEHAVIOR_COLLECTION_NAME = "behavior";
    public static final String DB_LOG_COLLECTION_NAME = "log";
    public static final String DB_FEEDBACK_COLLECTION_NAME = "feedBack";
    public static final String DB_COMMENT_COLLECTION_NAME = "comment";
    public static final String DB_APP_SEARCH_KEYS_COLLECTION_NAME = "appSearchKeyWord";
    public static final String DB_USER_SEARCH_KEYS_COLLECTION_NAME = "userSearchKeyWord";
    public static final String DB_GROUP_SEARCH_KEYS_COLLECTION_NAME = "groupSearchKeyWord";
    public static final String DB_MSG_USER_REF_COLLECTION_NAME = "msg_user_ref";
    public static final String DB_CATEGORY_RECOMMEND_REF_COLLECTION_NAME = "category_recommend_ref";
    public static final String DB_STATISTICS_LOG_COLLECTION_NAME = "statistics_log";
    public static final String DB_USER_AMOUNT_BASE_COLLECTION_NAME = "userAmount";
    public static final String DB_USER_VISITORS_COLLECTION_NAME = "userVisitors";
    public static final String DB_GROUP_COLLECTION_NAME = "group";
    public static final String DB_GROUP_JOIN_APPLY_COLLECTION_NAME = "groupJoinApply";
    public static final String DB_POST_COLLECTION_NAME = "post";
    public static final String DB_POST_REPLY_COLLECTION_NAME = "postReply";
    public static final String DB_CHANNEL_APPS_COLLECTION_NAME = "channelApps";
    public static final String DB_CLIENT_RECORD_DETAIL_COLLECTION_NAME = "clientRecordDetail";
    //Channel
    public static final String CHANNEL_APP_IS_MINE = "isMine";
    //Point system
    public static final String DB_GROUP_MILESTONE = "groupMilestone";
    public static final String DB_USER_REWARD_ACTION_DETAIL= "userRewardActionDetail";
    public static final String DB_USER_REWARD_HISTORY= "userRewardHistory";
    public static final String DB_USER_GROWTH_TREND = "userGrowthTrend";
    public static final String DB_GROUP_GROWTH_TREND = "groupGrowthTrend";
    public static final String DB_USER_APP_TOTAL_CONTRIBUTION = "userAppTotalContribution";
    public static final String DB_USER_GROUP_TOTAL_CONTRIBUTION = "userGroupTotalContribution";
    public static final String DB_GROUP_APP_TOTAL_CONTRIBUTION = "groupAppTotalContribution";
    public static final String IS_USER_IN_GROUP= "isIn";
    public static final String IS_READ= "isRead";
    
    public static final String DB_MSG_SYS_COLLECTION_NAME = "msgSystem";
    public static final String DB_MSG_SYS_USER_COLLECTION_NAME = "msgSystemUser";
    public static final String DB_MSG_GROUP_COLLECTION_NAME = "msgGroup";
    public static final String DB_MSG_GROUP_USER_COLLECTION_NAME = "msgGroupUser";
    public static final String DB_MSG_GUEST_BOOK_COLLECTION_NAME = "msgGuestBook";
    public static final String DB_MSG_USER_COLLECTION_NAME = "msgUser";
    public static final String DB_MSG_USER_DYNAMIC_COLLECTION_NAME = "msgUserDynamic";
    public static final String DB_USER_LEAVE_WORD_COLLECTION_NAME = "leaveWord";
    
    public static final String JSON_PARAMETERS_LABEL = "json_p";

    //DB query constants
    public static final String DB_QUERY_ORDER_BY = "orderBy";
    public static final int DB_QUERY_ORDER_BY_ASC = 1;
    public static final int DB_QUERY_ORDER_BY_DESC = -1;
    
    // pagenation
    public static final String LIMIT = "limit";
    public static final String LIMIT_START = "limitStart";
    public static final String LIMIT_KEYS = "limitKeys";
    public static final String TOTAL = "total";
    public static final String TOTAL_PAGES = "totalPages";
    public static final String RESULTS_DATA = "data";
    public static final String PAGENATION = "pagination";

    //user
    public static final String MY_APPS = "myApps";
    public static final String USER_NAME = "name";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static final String RESET_PASS_KEY = "resetKey";
    public static final String USER_ID = "userId";
    public static final String TARGET_USER_ID = "targetUserId";
    public static final String USER_IDS = "userIds";
    public static final String USER_LOGO = "userLogo";
    public static final String USER_LOGO_DEFAULT_M = "defaultUserLogoM";
    public static final String USER_LOGO_DEFAULT_F = "defaultUserLogoF";
    public static final String USER_NICK_NAME_DEFAULT = "defaultNickName";
    public static final String USER_NICK_NAME_DEFAULT_M = "defaultNickNameM";
    public static final String USER_NICK_NAME_DEFAULT_F = "defaultNickNameF";
    public static final String USER_BANNED_POST = "bannedPost";
    public static final String USER_BIRTH = "userBirth";
    public static final String GENDER = "gender";
    public static final int GENDER_MALE = 0;
    public static final int GENDER_FEMALE = 1;
    public static final String GENDER_MALE_STRING = "0";
    public static final String GENDER_FEMALE_STRING = "1";
    public static final String USER_FOLLOWING_COUNT = "followingCount";
    public static final String USER_FOLLOWER_COUNT = "followerCount";
    public static final String USER_LEVEL = "level";
    public static final String USER_LEVEL_NAME = "levelName";
    public static final String USER_LEVEL_CHILD = "levelChild";
    public static final String USER_VISITOR_COUNT = "visitorCount";
    public static final String USER_TAGS = "tags";
    public static final String USER_TAG_NAMES = "tagNames";
    public static final String USER_LATEST_GAMES = "latestGames";
    public static final String USER_GAMES = "games";
    public static final String USER_DEFAULT_BIRTH_DAY = "defaultBirthDay";
    public static final String USER_IS_STAR = "isStar";
    public static final String USER_DOWNLOAD_GAMES = "downloadGames";
    public static final String USER_INSTALL_GAMES = "installGames";
    public static final String USER_UNINSTALL_GAMES = "unInstallGames";

    public static final String USER_YEARS = "years";
    public static final String USER_CONSTELLATION = "constellation";
    public static final String USER_LAST_LOGIN = "lastLogin";
    public static final String USER_FOLLOWED = "followed";
    public static final String USER_ACCOUNT_USER = "accountUser";
    public static final String USER_RECOMMEND_POINT = "recommendPoint";
    public static final String USER_EXP = "exp";
    public static final String USER_NEXT_EXP = "nextExp";
    public static final String USER_GROUP_ROLE = "groupRole";
    public static final String USER_ATTRICTIVE_POINT = "attractivePoint";
    
    public static final String USER_VITALITY_EXP = "vitalityExp";
    public static final String USER_CHARM_EXP = "charmExp";
    public static final String IS_MY_APPS = "isMyApp";
    
    public static final String USER_MESSAGE = "latestMsg";
    public static final String USER_AGE_START = "ageStart";
    public static final String USER_AGE_TO = "ageTo";
    public static final String CITY = "city";
    
    public static final String USER_RANKING_IN_ALL = "rankAll";
    public static final String USER_IS_ATTRACTIVE_USER = "isAttractive";
    public static final String USER_RANK_IN_APP="rankInApp";
    public static final String USER_PRAISED_COUNT = "praisedCount";
    public static final String USER_IS_PRAISED = "isPraised";
    public static final String USER_SCORE_IN_APP="scoreInApp";
    public static final String USER_ADMIN_SCORE = "adminScore";
    public static final String USER_GROUP_NAME="groupName";
    public static final String USER_GROUP_TYPE="groupType";
    public static final String USER_IS_JOIN_GROUP="isJoinGroup";
    
    public static final String SYSTEM_USER_DEFAULT_LOGO = "defaultSystemUserLogo";
    
    public static final String SYSTEM_USER_NAME = "systemUserName";

    public static final String USER_REWARD_TIME = "rewardTime";
    
    public static final String USER_PROMOTED_TO_VICE_LEADER_TIME = "toViceLeaderTime";
    
    public static final String USER_LOGO_UPDATE_TIMES = "logoUpdateTimes";
    public static final String USER_BASEINFO_UPDATE_TIMES = "baseInfoUpdateTimes";
    public static final String MY_APPS_COUNT = "myAppsCount";
    public static final String USER_AGE = "age";
    public static final String USER_PHOTO_COUNT = "photoCount";
    public static final String USER_VISITORS = "visitors";

    public static final String USER_GROW_RATIO = "userGrowRatio";
    public static final String GROUP_GROW_RATIO = "groupGrowRatio";
    
    //User's setting
    public static final String USER_SETTING_UNDESIRE_FIND_ME = "unFindMe";
    public static final String USER_SETTING_UNDESIRE_PUBLIC_MY_GAMES = "unPubMyGames";
    public static final String USER_SETTING_UNDESIRE_PUBLIC_MY_ACTIVITIES = "unPubMyActivity";
    public static final String USER_SETTING_AUTO_WELCOME_NEW_GAMER = "autoWelcomeNewer";
    public static final String USER_SETTING_RECEIVE_MESSAGES = "receiveMess";
    public static final String USER_SETTING_RECEIVE_MESSAGE_RATE = "receiveRate";
    public static final String RECEIVE_RATE_1 = "1";
    public static final String RECEIVE_RATE_2 = "2";
    public static final String RECEIVE_RATE_4 = "4";
    public static final String RECEIVE_RATE_24 = "24";
    public static final String TRUE = "1";
    public static final String FALSE = "0";

    //User feedback
    public static final String FEEDBACK_CONTENT = "content";
    
    // private message
    public static final String SENDER_ID = "senderId";
    public static final String MESSAGE_CONTENT = "messageContent";

    // follow
    public static final String FOLLOWER_ID = "followerId";

    // visit
    public static final String VISIT_ID = "visitId";
    public static final String VISITOR_ID = "visitorId";

    // response status
    public static final String CODE = "code";

    // comment
    public static final String COMMENT = "comment";
    public static final String COMMENT_QUESTION = "question";
    public static final String COMMENT_ID = "commentId";
    public static final String SCORE = "score";
    public static final String COMMENT_TYPE = "type";
    public static final String COMMENT_REPLIES = "replies";
    public static final String COMMENT_BANNED = "banned";

    //APP
    public static final String APPS = "apps";
    public static final String APP_NAMES = "appNames";
    public static final String APP_FEE = "fee";
    public static final String APP_NAME = "name";
    public static final String APP_TOP_RECOMM_IMG = "topRecommImgUrl";
    public static final String APP_LIST_RECOMM_IMG = "listRecommImgUrl";
    public static final String APP_LOGO_URL = "logoUrl";
    public static final String APP_SIZE = "size";
    public static final String APP_PACKAGE_NAME = "packageName";
    public static final String APP_VERSION_CODE = "versionCode";
    public static final String APP_DEVELOPER = "developer";
    public static final String APP_DOWNLOAD_URL = "downloadUrl";
    public static final String APP_VERSION = "versionName";
    public static final String APP_DESCRIPTION = "description";
    public static final String APP_TOTAL_DOWNLOAD = "totalDownloadTimes";
    public static final String APP_TOTAL_DOWNLOAD_BASE = "downloadBase";
    public static final String APP_ADMIN_COMMENT = "adminComment";
    public static final String APP_SCORE = "score";
    public static final String APP_CHINESE_NAME = "chineseName";
    public static final String APP_RECOMMEND = "isRecommend";
    public static final String APP_SCREEN_SHOT_MOBILE = "screenShotMobile";
    public static final String APP_SCREEN_SHOT_PC = "screenShotPc";
    public static final String APP_REQUIRED_SYSTEM = "requiredSystem";
    public static final String APP_CATEGORY = "category";
    public static final String APP_CATEGORY_IDS = "cateIds";
    public static final String APP_PACKAGE_NAMES = "packageNames";
    public static final String APP_START_UP_SPEED = "startUpSpeed";
    public static final String APP_SCORE_NUMS = "scoreNums";
    public static final String APP_ACTIVITY = "activity";
    public static final String APP_COMMENDATION = "commendation";
    public static final String APP_ACTIVITY_IMAGE = "activityImage";
    public static final String APP_COMMENDATION_IMAGE = "commendationImage";
    public static final String APP_ACTIVITY_PRIORITY = "activityPriority";
    public static final String APP_COMMENDATION_PRIORITY = "commendationPriority";
    public static final String APP_ADMIN_SCORE = "adminScore";
    public static final String APP_ON_LINE="onLine";
    public static final String APP_MATCHING = "matching";
    public static final int APP_MATCHING_0 = 0;
    public static final int APP_MATCHING_1 = 1;
    public static final int APP_MATCHING_2 = 2;
    public static final int APP_MATCHING_3 = 3;
    public static final int APP_MATCHING_4 = 4;
    public static final String APP_YULE_GAME = "isYuleGame";
    public static final String APP_FIRST_GROUP="firstGroup";

    public static final String APP_CATEGORY_ADD = "add";
    public static final String APP_TOP3_GROUP = "top3Group";
    public static final String APP_CHARMER = "appCharmer";
    public static final String APP_STORY = "appStory";
    public static final String APP_GUIDE = "appGuide";
    public static final String APP_DISCUSS = "appDiscuss";
    public static final String APP_POST = "appPost";
    public static final String APP_STORY_AMOUNT = "appStoryAmount";
    public static final String APP_GUIDE_AMOUNT = "appGuideAmount";
    public static final String APP_DISCUSS_AMOUNT = "appDiscussAmount";

    public static final String APP_GROUP_AMOUNT = "appGroupAmount";
    public static final String APP_USER_RANKING_LIST = "appUserRankingList";
    public static final String CHANNEL_ID_FROM_APP = "appChannelId";
    public static final String APP_TYPE = "appType";
    public static final String APP_UPDATE_TIMES = "updateTimes";
    
    //message
    public static final String MSG_CONTENT = "content";
    public static final String MSG_TYPE = "type";
    public static final String MSG_FROM = "from";
    public static final String MSG_URL = "url";
    public static final String MSG_FROM_SYSTEM = "SYSTEM";
    public static final String MSG_TO = "to";
    public static final String MSG_ID = "messageId";
    public static final String MSG_STATUS = "status";
    public static final String MSG_TO_TYPE = "toType";
    public static final String MSG_GROUP_ID = "groupId";
    public static final String MSG_REFER_ID = "referId";
    public static final String MSG_REPLY_TO = "replyTo";
    public static final String MSG_REPLY_TO_NAME = "replyToName";
    
    // app comment json
    public static final String _COMMENT_APP_ID = "cAppId";
    public static final String _COMMENT_APP_NAME = "cAppName";
    public static final String _COMMENT_APP_REPLY_COUNT = "cAppReplyCount";
    public static final String _COMMENT_APP_SCORE = "cAppScore";
    public static final String _COMMENT_APP_COMMENT = "cAppComment";
    public static final String _COMMENT_APP_COMMENT_ID = "cAppCommentId";
    public static final String _COMMENT_APP_TYPE = "cAppCommentType";
    public static final String _COMMENT_DATE = "cAppCommentDate";
    public static final String _COMMENT_REPLY_USER_ID = "cAppReplyUserId";
    public static final String _COMMENT_REPLY_USER_LOGO = "replyUserLogo";
    public static final String _COMMENT_REPLY_USER_NAME = "replyUserName";
    public static final String _COMMENT_REPLY_COMMENT = "replyComment";
    public static final String _COMMENT_REPLY_DATE = "replyDate";
    
    
    //STATISTICS 
    public static final String STATISTICS_LOG_TYPE = "type";
    public static final String STATISTICS_LAST_EXECUTE_TIME = "lastExecuteTime";
    
    //Yeas and Constellations
    public static final String YEARS_OLD = "50";
    public static final String YEARS_60 = "60";
    public static final String YEARS_70 = "70";
    public static final String YEARS_80 = "80";
    public static final String YEARS_90 = "90";
    public static final String YEARS_00 = "00";
    
    public static final String SHUIPING = "1";
    public static final String SHUANGYU = "2";
    public static final String BAIYANG = "3";
    public static final String JINGNIU = "4";
    public static final String SHUANGZI = "5";
    public static final String JUXIE = "6";
    public static final String SHIZI = "7";
    public static final String CHUNUE = "8";
    public static final String TIANCHENG = "9";
    public static final String TIANXIE = "10";
    public static final String SHESHOU = "11";
    public static final String MOJIE = "12";

    //Report
    public static final String REPORT_TIME_START = "start";
    public static final String REPORT_TIME_TO = "to";
    public static final String REPORT_HAS_FOLLOWING_USER_AMOUNT = "hasFollowingUserAmount";
    public static final String REPORT_USER_VISITED_TIMES = "visitedTimes";
    public static final String REPORT_MESSAGE_DAY_AMOUNT = "messageAmount";
    public static final String REPORT_MESSAGE_DAY_SENT_USER_AMOUNT = "sentUserAmount";
    public static final String REPORT_APP_DAY_LAUNCH_MOBILE_AMOUNT = "dayLaunchMobAmount";
    public static final String REPORT_APP_DAY_LAUNCH__ACCOUNT_AMOUNT = "dayLaunchAccountAmount";
    public static final String REPORT_APP_DOWNLOAD_ACCOUNT_AMOUNT = "downloadAccountAmount";
    public static final String REPORT_APP_DOWNLOAD_MOBILE_AMOUNT = "downloadMobileAmount";
    public static final String REPORT_MOBILE_AMOUNT = "mobileAmount";
    public static final String REPORT_MOBILE_IS_MSG_AMOUNT = "mobileIsMsgAmount";
    public static final String REPORT_REGISTER_TOTAL_AMOUNT = "registerAmount";
    public static final String REPORT_FOLLOW_EACH_OTHER_AMOUNT = "followEachotherAmount";
    public static final String REPORT_INSTALL_AMOUNT = "installAmount";//an zhuang
    public static final String REPORT_ACTIVATE_AMOUNT = "activateAmount";//ji huo
    public static final String REPORT_ACTIVE_AMOUNT = "activeAmount";// huo yue
    public static final String REPORT_APP_DOWNLOAD_AMOUNT = "appDownloadAmount";
    public static final String REPORT_APP_OPEN_AMOUNT = "appOpenAmount";
    public static final String REPORT_APP_JIHUO_AMOUNT = "appJiHuoAmount";
    //Group
    public static final String GROUP_NAME = "name";
    public static final String GROUP_LEADER = "leader";
    public static final String GROUP_VICE_LEADER = "viceLeader";
    public static final String GROUP_IMAGE_SPEAKER = "imageSpeaker";
    public static final String GROUP_TYPE = "type";
    public static final String GROUP_SLOGAN = "slogan";
    public static final String GROUP_USER_AMOUNT = "userAmount";
    public static final String GROUP_USER_AMOUNT_HISTORY = "userAmountHistory";
    public static final String GROUP_POINT = "point";
    public static final String GROUP_EXP = "exp";
    public static final String GROUP_NEXT_EXP = "nextExp";
    public static final String GROUP_ID = "groupId";
    public static final String GROUP_IS_JOINED = "isJoined";
    public static final String GROUP_LOGO = "logo";
    public static final String GROUP_APP_AMOUNT = "appAmount";
    public static final String GROUP_LEVEL = "level";
    public static final String GROUP_OCCUPY_APP_HISTORY_AMOUNT = "occupyAppHistoryAmount";
    
    public static final String GROUP_MEMBERS = "members";
    public static final String GROUP_LEADER_NAME = "leaderName";
    public static final String GROUP_VICE_LEADER_NAME = "viceLeaderName";

    public static final String GROUP_APPLY_STATUS = "status";
    public static final int GROUP_APPLY_APPLY = 0;
    public static final int GROUP_APPLY_PASSED = 1;
    public static final int GROUP_APPLY_REFUSED = 2;
    public static final int GROUP_ROLE_LEADER = 9;
    public static final int GROUP_ROLE_VICE_LEADER = 8;
    public static final int GROUP_ROLE_MEMBER = 0;
    
    public static final String GROUP_HOT_VALUE = "hotValue";
    
    public static final String POST_TITLE = "title";
    public static final String POST_CONTENT = "content";
    public static final String POST_TYPE = "type";
    public static final String POST_IS_TOP = "isTop";
    //public static final String POST_USERID = "userId";
    public static final String POST_FROM = "from";
    public static final String POST_STATUS = "status";
    public static final String POST_IS_ANONYMOUS = "isAnonymous";
    public static final String POST_ATTACHMENT = "attachment";
    public static final String POST_UPSCORE = "upScore";
    public static final String POST_DOWNSCORE = "downScore";
    public static final String POST_SCORETIMES = "scoreTimes";
    public static final String POST_IS_HIGHLIGHT = "isHighlight";
    public static final String POST_IS_PASSED = "isPassed";
    public static final String POST_READ_AMOUNT = "readAmount";
    public static final String POST_REPLY_AMOUNT = "replyAmount";
    
    public static final String POST_ID = "postId";
    public static final String POST_REPLY_ID = "replyId";
    public static final String POST_REPLY_CONTENT = "content";
    public static final String POST_REPLY_STATUS = "status";
    public static final String POST_REPLY_TO = "replyTo";
    public static final String POST_REPLY_TONAME = "replyToName";
    
    public static final String POST_IS_PRAISED = "isPraised";
    public static final String POST_CAN_DELETE = "canDelete";
    public static final String GROUP_IS_FIRST = "isFirstGroup";
    public static final String TOTAL_EXP="totalExp";
    public static final String TOTAL_POINT="totalPoint";
    public static final String TOTAL_EXP_FOR_APP="totalExpForApp";
    public static final String TOTAL_EXP_FOR_GROUP="totalExpForGroup";
    public static final String TOTAL_POINT_FOR_APP="totalPointForApp";

    public static final String GROUP_CREATE_COST_POINT = "createGroupCostPoint";
    
    public static final String GROUP_MILESTONE_CONTENT = "content";

    public static final String GROUP_MILESTONE_CREATE="milestoneCreate";
    public static final String GROUP_MILESTONE_STATION_APP="milestoneStationApp";
    public static final String RANKING="ranking";
    public static final String GROUP_OCCUPY_APP_AMOUNT="occupyAppAmount";
    public static final String GROUP_STATION_APP_AMOUNT="stationAppAmount";
    public static final String GROUP_STATION_APPS="stationApps";
    public static final String GROUP_APP="groupApp";
    public static final String GROUP_LATEST_ACTIVITY_POST="latestActivityPost";
    public static final String GROUP_HOT_ORDER_BY_TYPE="orderByType";
    public static final String GROUP_HOT_IS_MY_APP="isMyApp";
    public static final String GROUPS="groups";
    
    //Home top daily message
    public static final String HOME_TOP_DAILY_GUIDE_CONTENT = "content";
//    public static final String HOME_TOP_DAILY_GUIDE_POST_ID = "postId";
//    public static final String HOME_TOP_DAILY_GUIDE_GROUP_ID = "groupId";
    public static final String HOME_TOP_DAILY_GUIDE_REFER_DATA = "referData";
    public static final String HOME_TOP_DAILY_GUIDE_TYPE = "type";
    public static final String HOME_TOP_DAILY_GUIDE_POINT_REWARD_AMOUNT = "amount";
    
    public static final String HOME_TOP_DAILY_GUIDE_FIRST_LOGIN_CONTENT = "dailyGuideFirstLoginContent";
    public static final String HOME_TOP_DAILY_GUIDE_JOIN_GROUP_CONTENT = "dailyGuideJoinGroupContent";
    public static final String HOME_TOP_DAILY_GUIDE_REWARD_BOX_CONTENT = "dailyGuideRewardBoxContent";
    public static final String HOME_TOP_DAILY_GUIDE_USER_FOLLOW_CONTENT = "dailyGuideUserFollowContent";

    public static final int HOME_TOP_TYPE_FIRST_LOGIN_GUIDE = 1;
    public static final int HOME_TOP_TYPE_JOIN_GROUP_GUIDE = 2;
    public static final int HOME_TOP_TYPE_INVITE_JOIN_GROUP_GUIDE = 3;
    public static final int HOME_TOP_TYPE_NEW_FOLLWER_GUIDE = 4;
    public static final int HOME_TOP_TYPE_BROADCAST_MESSAGE_GUIDE = 5;
    public static final int HOME_TOP_TYPE_REWARD_BOX_GUIDE = 6;

    public static final String HOME_TOP_GUIDE_PLANTFORM_INTRODUCE = "plantFormIntroduce";
    public static final String HOME_TOP_GUIDE_GROUP_INTRODUCE = "groupIntroduce";
    public static final String HOME_TOP_GUIDE_GROUP_JOIN_INVITE = "groupJoinInvite";
    public static final String HOME_TOP_GUIDE_HAS_NEW_FOLLOWER = "hasNewFollower";
    public static final String HOME_TOP_GUIDE_BROADCAST_INFO = "broadcastInfo";
    public static final String HOME_TOP_GUIDE_REWARD_BOX = "rewardBox";
    
    public static final String TYPE = "type";
    public static final String REFER_ID = "referId";
    
    public static final String PUSH_SERVER_URL = "PushServerUrl";
    public static final String PUSH_MSG_API = "/ypush/priMsgPush.action?method=receive";
    public static final String DB_MSG_SYNC_PUSH_COLLECTION_NAME = "msgSyncPush";
    public static final String PUSH_MSG_TYPE = "pushType";
    
    //pack app project
    public static final String DB_PACK_MOBILE_COLLECTION_NAME = "packMobile";
    public static final String PACK_MOBILE_ACCOUNT_ID = "accountID";
    public static final String PACK_BEHAVIOR_TYPE = "behaviorType";
    public static final String BEHAVIOR_TYPE = "behaviorType";
    public static final String DB_PACK_CLIENT_COLLECTION_NAME = "packClient";
    public static final String DB_QINGCHENG_CLIENT_COLLECTION_NAME = "qingChengClient";
    public static final String DB_PACK_LOG_COLLECTION_NAME = "packLog";
    
    //channel
    public static final String CHANNEL_CO_TYPE = "coType";
    public static final String CHANNEL_CO_TYPE_CPS = "CPS";
    public static final String CHANNEL_CO_TYPE_CPA = "CPA";
    public static final String CHANNEL_CO_TYPE_PRICE = "coPrice";

    public static final String CLIENT_NAME = "clientName";
    public static final Integer CLIENT_YULOR = 0;
    public static final Integer CLIENT_HOTAPPS = 1;
    public static final Integer CLIENT_QINGCHENG_APPSTORE = 2;
    
    public static final String BEGIN_TIME = "beginTime";
    public static final String UPLOAD_TIME = "uploadDate";

    public static final String CHANNEL_IDS = "channelIds";
    
}
