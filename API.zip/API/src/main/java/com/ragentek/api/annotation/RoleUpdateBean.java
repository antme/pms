package com.ragentek.api.annotation;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;

import com.ragentek.api.dao.ICommonDao;

public class RoleUpdateBean {

	public static void init(ICommonDao dao) {
		System.out.println(dao.getClass().getName());

		System.out.println("init called**************************");

		ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(true);
		scanner.resetFilters(false);
		scanner.addIncludeFilter(new AnnotationTypeFilter(RoleValidate.class));

		for (BeanDefinition bd : scanner
				.findCandidateComponents("com.ragentek.api")) {
			System.out.println(bd.getBeanClassName());

		}

	}

}
