package com.ragentek.api.service.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ragentek.api.dbhelper.DBQuery;
import com.ragentek.api.dbhelper.DBQueryOpertion;
import com.ragentek.api.exception.ApiResponseCodeException;
import com.ragentek.api.service.AbstractService;
import com.ragentek.api.service.IUserService;
import com.ragentek.api.util.ApiConstants;
import com.ragentek.api.util.ApiUtil;
import com.ragentek.api.util.status.ResponseCodeConstants;

public class UserServiceImpl extends AbstractService implements IUserService {

    private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);



    @Override
    public String register(Map<String, Object> parameters) {
        // load default settings from cheng you account, set to register user as
        // default value
        validate(parameters, "register");
        String chengyouId = (String) parameters.get(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID);
        String channelId = (String) parameters.get(ApiConstants.CHANNEL_ID);
        String email = (String) parameters.get(ApiConstants.EMAIL);
        String pwd = (String) parameters.get(ApiConstants.PASSWORD);

        Map<String, Object> regQuery = new HashMap<String, Object>();

        regQuery.put(ApiConstants.CHENG_GAME_MOBILE_ID, chengyouId);
        regQuery.put(ApiConstants.EMAIL, new DBQuery(DBQueryOpertion.NOT_NULL));

        Map<String, Object> reguser = dao.findOneByQuery(regQuery, ApiConstants.DB_USER_COLLECTION_NAME);
        String id = null;

        int gender = 0;

        if (reguser == null) {

            Map<String, Object> mobileQuery = new HashMap<String, Object>();
            mobileQuery.put(ApiConstants.CHENG_GAME_MOBILE_ID, chengyouId);

            Map<String, Object> user = dao.findOneByQuery(mobileQuery, ApiConstants.DB_USER_COLLECTION_NAME);
            // if has registered account,then create a new account; else update
            // db user

            if (null != user) {
                // update mobile user
                user.put(ApiConstants.EMAIL, email);
                user.put(ApiConstants.PASSWORD, pwd);
                dao.updateById(user, ApiConstants.DB_USER_COLLECTION_NAME);
                id = user.get(ApiConstants.MONGO_ID).toString();
            } else {
                logger.error("DB have no mapping user record for chengyouID :　" + chengyouId);
            }
        } else {
            gender = ApiUtil.getIntegerParam(reguser, ApiConstants.GENDER);
        }
        return id;
    }


    @Override
    public void updateUserInfo(Map<String, Object> userInfoMap) {

        String currentUserId = null;
        userInfoMap.put(ApiConstants.MONGO_ID, currentUserId);
        this.validate(userInfoMap, "update");
        Map<String, Object> uQuery = new LinkedHashMap<String, Object>();
        uQuery.put(ApiConstants.LIMIT_KEYS, new String[] { ApiConstants.USER_LOGO_UPDATE_TIMES, ApiConstants.USER_BASEINFO_UPDATE_TIMES });
        uQuery.put(ApiConstants.MONGO_ID, currentUserId);
        Map<String, Object> user = dao.findOneByQuery(uQuery, ApiConstants.DB_USER_COLLECTION_NAME);

        // If empty, not need update user logo
        if (ApiUtil.isEmpty(userInfoMap.get(ApiConstants.USER_LOGO))) {
            userInfoMap.remove(ApiConstants.USER_LOGO);
        } else {
            Integer lt = ApiUtil.getIntegerParam(user, ApiConstants.USER_LOGO_UPDATE_TIMES);
            lt = (lt == null) ? 1 : lt + 1;
            userInfoMap.put(ApiConstants.USER_LOGO_UPDATE_TIMES, lt);
        }

        Long userBirth = ApiUtil.getLongParam(userInfoMap, ApiConstants.USER_BIRTH);
        if (userBirth != null) {
            userInfoMap.put(ApiConstants.USER_BIRTH, userBirth);
            Map<String, Object> yearsCons = new HashMap<String, Object>();
            try {
                yearsCons = ApiUtil.getYearsAndConstellation(userBirth);
            } catch (ParseException e) {
                throw new ApiResponseCodeException(String.format("User's birth is illegal when try to update user info [%s] ", userInfoMap), ResponseCodeConstants.U_BIRTH_ILLEGAL);
            }
            userInfoMap.put(ApiConstants.USER_YEARS, yearsCons.get(ApiConstants.USER_YEARS));
            userInfoMap.put(ApiConstants.USER_CONSTELLATION, yearsCons.get(ApiConstants.USER_CONSTELLATION));

            Integer bt = ApiUtil.getIntegerParam(user, ApiConstants.USER_BASEINFO_UPDATE_TIMES);
            bt = (bt == null) ? 1 : bt + 1;
            userInfoMap.put(ApiConstants.USER_BASEINFO_UPDATE_TIMES, bt);
        }
        Integer gender = ApiUtil.getIntegerParam(userInfoMap, ApiConstants.GENDER);
        userInfoMap.put(ApiConstants.GENDER, gender);
        dao.updateById(userInfoMap, ApiConstants.DB_USER_COLLECTION_NAME);
    }

    @Override
    public String login(Map<String, Object> parameters) {
        this.validate(parameters, "login");
        Map<String, Object> query = new HashMap<String, Object>();
        query.put(ApiConstants.EMAIL, parameters.get(ApiConstants.EMAIL));
        query.put(ApiConstants.PASSWORD, parameters.get(ApiConstants.PASSWORD));
        query.put(ApiConstants.LIMIT_KEYS, new String[] { ApiConstants.USER_LAST_LOGIN });
        Map<String, Object> user = dao.findOneByQuery(query, ApiConstants.DB_USER_COLLECTION_NAME);
        if (user == null) {
            throw new ApiResponseCodeException(String.format("Name or password is incorrect when try to login [%s] ", parameters),
                    ResponseCodeConstants.USER_LOGIN_USER_NAME_OR_PASSWORD_INCORRECT);
        }
        user.put(ApiConstants.USER_LAST_LOGIN, new Date().getTime());
        dao.updateById(user, ApiConstants.DB_USER_COLLECTION_NAME);
        return (String) user.get(ApiConstants.MONGO_ID);
    }

    @Override
    public String geValidatorFileName() {
        return "user";
    }


    @Override
    public String logout(Map<String, Object> parameters) {
        return null;
    }
   
}
