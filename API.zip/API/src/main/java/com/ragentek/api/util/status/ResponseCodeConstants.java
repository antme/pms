package com.ragentek.api.util.status;

public class ResponseCodeConstants {
    // *********Common
    public static final String PARAMETERS_EMPTY = "-4";
    public static final String ID_IS_NULL = "-5";
    public static final String ID_NO_RECORD_IN_DB = "-6";
    public static final String NUMBER_PARAMETER_ILLEGAL = "-9";
    public static final String USER_BANNED_PUBLISH = "user_banned";
    
    public static final String SERVER_ERROR = "-1";
    
    
    public static final String  PARAMETERS_NOT_JSON = "-2";
    // *********Common end

    // *********User
    // list
    public static final String GENDER_ILLEGAL = "1";
    public static final String BANNED_POST_ILLEGAL = "2";

    // Login

    // Follow
    public static final String FOLLOW_USER_ID_NULL = "1";
    public static final String FOLLOW_USER_ID_NO_DB_RECORD = "2";

    // Visitor
    public static final String VISITOR_USER_ID_NULL = "1";
    public static final String VISITOR_USER_ID_NO_DB_RECORD = "2";

    // Banned post
    public static final String BANNED_USER_ID_IS_NULL = "1";
    public static final String BANNED_VALUE_ILLEGAL = "2";

    // Reset password
    public static final String RESET_PASS_PASSWORD_EMPTY = "1";
    public static final String RESET_PASS_EMAIL_EMPTY = "2";
    public static final String RESET_PASS_KEY_EMPPTY = "3";
    public static final String RESET_PASS_KEY_ILLEGAL = "4";
    public static final String RESET_PASS_NO_MAPPING_DB_RECORD = "5";
    public static final String RESET_PASS_CHECK_INPUT_EMPTY = "6";
    
    public static final String USER_ALREADY_JOINED_A_GROUP = "user_already_in_group";
    public static final String USER_NOT_JOINED_A_GROUP = "user_not_in_group";
    public static final String CUR_USER_NOT_JOINED_A_GROUP = "cur_user_not_in_group";
    // *********User end

    // *********User Tag
    // Delete
    public static final String USER_TAG_CANNOT_DELETE_BIND_USERS = "1";
    // *********User Tag end

    // *********App
    public static final String APP_PACKAGE_NAME_CAN_NOT_EMPTY = "app_package_name_can_not_empty";
    public static final String APP_VERSION_CODE_CAN_NOT_EMPTY = "app_version_code_can_not_empty";
    public static final String APP_CHANNEL_ID_CAN_NOT_EMPTY = "app_channel_id_can_not_empty";
    public static final String APP_CATEGORY_DB_NOT_ARRAY_VALUE = "1";

    // App search API
    public static final String APP_SEARCH_IS_RECOMMEND_ILLEGAL = "1";
    public static final String APP_SEARCH_COMMENDATION_ILLEGAL = "2";
    public static final String APP_SEARCH_ACTIVITY_ILLEGAL = "3";

    // App recommend
    public static final String APP_COMMENDATION_IMAGE_NULL = "1";
    public static final String APP_ACTIVITY_IMAGE_NULL = "2";

    // App online
    public static final String APP_ONLINE_APP_ID_NULL = "1";
    public static final String APP_ONLINE_ILLEGAL = "2";
    public static final String APP_ONLINE_APP_ID_EMPTY = "3";

    // App comment
    public static final String APP_COMMENT_BANNED_NULL = "1";
    public static final String APP_COMMENT_BANNED_ILLEGAL = "2";
    
    // App group
    public static final String APP_HAVE_NO_GROUP="no_any_group";

    // *********App end

    // *********App category

    // Delete API
    public static final String CATEGORY_CANNOT_DELETE_HAS_APP = "app_categroy_has_app";
    public static final String CATEGORY_CANNOT_DELETE_HAS_BIND = "app_categroy_has_bind_to_user_tag";

    // Category bind to user tag or gender for recommend
    public static final String RECOMMEND_BIND_CATEGORY_NOT_EXISTS = "1";

    // *********App category end

    // user behavior file upload
    public static final String BEHAVIOR_UPLOAD_DECRYPT_ERROR = "1";
    public static final String BEHAVIOR_UPLOAD_FILE_ERROR = "2";

    // comment
    // list app comments
    public static final String LIST_APP_COMMENTS_APP_ID_IS_NULL = "1";
    public static final String LIST_APP_COMMENTS_APP_NOT_EXSISTS = "2";

    public static final String LIST_USER_COMMENTS_USER_ID_IS_NULL = "1";
    public static final String LIST_USER_COMMENTS_USER_NOT_EXSISTS = "2";

    // message
    public static final String REPLY_MESSAGE_FROM_IS_NULL = "1";
    public static final String REPLY_MESSAGE_FROM_NOT_EXSISTSL = "2";
    public static final String REPLY_MESSAGE_MESSAGE_ID_IS_NULL = "3";
    public static final String REPLY_MESSAGE_MESSAGE_NOT_EXSISTS = "4";
    public static final String REPLY_MESSAGE_MESSAGE_CONTENT_IS_NULL = "5";

    public static final String SEND_USER_MESSAGE_FROM_IS_NULL = "msg_from_null";
    public static final String SEND_USER_MESSAGE_TO_IS_NULL = "msg_to_null";
    public static final String SEND_USER_MESSAGE_FROM_NOT_EXISTS = "msg_from_not_exists";
    public static final String SEND_USER_MESSAGE_TO_NOT_EXISTS = "msg_to_not_exists";
    public static final String SEND_USER_MESSAGE_CONTENT_IS_NULL = "msg_content_empty";
    public static final String MSG_TYPE_NOT_EXISTS = "msg_type_not_exists";
    public static final String MSG_STATUS_NOT_EXISTS = "msg_status_not_exists";
    /********************* USER SETVICE ********************************************/

    // REGISTER
    public static final String REGISTER_NAME_OR_PWD_EMPTY = "username_or_pass_empty";
    public static final String REGISTER_EMAIL_EXISTS = "user_exists";
    public static final String NOT_REGISTER = "user_not_register";

    // UPDATE USER
    public static final String U_ID_NULL = "id_empty";
    public static final String U_USER_NOT_EXISTS = "user_not_exists";
    public static final String U_GENDER_ILLEGAL = "gender_illegal";
    public static final String U_BIRTH_ILLEGAL = "user_birth_illegal";
    public static final String U_NAME_EMPTY = "5";
    public static final String U_NAME_EXISTS = "6";

    // VIEW USER INFO
    public static final String V_USER_ID_EMPTY = "view_user_id_empty";
    public static final String V_USER_NOT_EXISTS = "view_user_not_exists";

    // LOAD SETTING
    public static final String LS_USER_NOT_EXISTS = "user_not_exists";
    public static final String USRE_UNDESIRE_PUB_HIS_GAMES = "user_undesire_pub_his_games";

    // UPDATE SETTING
    public static final String US_ID_OR_MOBILD_ID_NULL = "1";
    public static final String US_USER_NOT_EXIST = "user_not_exists";
    public static final String US_MOBILD_ID_NOT_EXISTS = "3";

    // ADD FEEDBACK
    public static final String AF_ID_OR_MOBILD_ID_NULL = "1";
    public static final String AF_USER_NOT_EXIST = "2";
    public static final String AF_FEEDBACK_EMPTY = "feedback_empty";
    public static final String AF_MOBILD_ID_NOT_EXISTS = "4";

    // ADD FOLLOW
    public static final String AFO_USER_ID_NULL = "add_follow_user_id_empty";
    public static final String AFO_FOLLOWER_ID_NULL = "add_follow_follower_id_empty";
    public static final String AFO_USER_NOT_EXISTS = "add_follow_user_not_exists";
    public static final String AFO_FOLLOWER_NOT_EXISTSL = "add_follow_follower_not_exists";
    public static final String AFO_FOLLOWER_EXISTS = "already_followed";
    public static final String AFO_FOLLOWER_CANNOT_FOLLOW_SELF = "add_follow_self";

    // UNFOLLOW
    public static final String UNFO_FOLLOW_NOT_EXISTS = "1";

    // LOGIN
    public static final String USER_LOGIN_NAME_OR_PWD_EMPTY = "username_or_pass_empty";
    public static final String USER_LOGIN_USER_NAME_OR_PASSWORD_INCORRECT = "username_or_pass_incorrect";

    // ADD FOLLOW
    public static final String LIST_USER_LATEST_APPS_USER_ID_NULL = "1";

    // LOAD APP INFO
    public static final String LO_APP_ID_NULL = "1";
    public static final String LO_APP_NOT_EXISTS = "app_not_exists";

    // ADD APP QUESTION
    public static final String USER_ID_REQUIRED_OR_USER_NOT_EXISTS = "1";
    public static final String APP_ID_REQUIRED = "app_id_required";
    public static final String APP_NOT_EXISTS = "app_not_exists";
    public static final String APP_COMMENT_EMPTY = "app_comment_empty";

    // ADD APP COMMENT
    public static final String APP_SCORE_EMPTY = "app_score_empty";
    public static final String APP_SCORE_NOT_VALID = "app_score_invalid";

    // REPLY COMMENT
    public static final String COMMENT_ID_REQUIRED="comment_id_required";
    public static final String COMMENT_NOT_EXISTS = "comment_not_exists";

    
    // GROUP
    public static final String GROUP_NAME_EXIST = "group_name_exist";
    public static final String GROUP_NAME_EMPTY = "group_name_empty";
    public static final String GROUP_TYPE_EMPTY = "group_type_empty";
    public static final String GROUP_ALREADY_IN_APP = "group_already_in_app";
    public static final String GROUP_USER_ALREADY_IN_A_GROUP = "user_already_has_group";
    public static final String GROUP_USER_DUPLICATE_APPLY_FOR_THIS_GROUP = "user_already_applied";
    public static final String GROUP_NO_PERMISSION_STATION_IN_APP = "only_group_leader_can_do_station";

    public static final String GROUP_USER_NOT_LEADER = "group_user_not_group_leader";
    public static final String GROUP_ALREADY_HAS_VICE_LEADER = "group_already_has_vice_leader";
    public static final String GROUP_APPLY_USER_ALREADY_JOINED_OTHER_GROUP = "this_user_already_joined_other_group";
    
    public static final String GROUP_NO_PERMISSION_ADD_NOTICE = "only_group_leader_can_add_notice";
    public static final String NOT_GROUP_LEADER = "not_group_leader";
    public static final String GROUP_ONLY_ONE_LEADER_MEMBER_CANNOT_EXIT="only_one_leader_cannot_exit";
    //
	public static final String POST_STATUS_NOT_RIGHT = "post_status_not_right";	
	public static final String POST_REPLY_TO_NOT_EXIST = "post_replyTo_not_exist";
	public static final String POST_NOT_EXIST = "post_not_exist";	
}
