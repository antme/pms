package com.ragentek.api.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

import com.ragentek.api.dao.ICommonDao;
import com.ragentek.api.service.AbstractService;
import com.ragentek.api.service.IBehaviorService;
import com.ragentek.api.service.IGroupService;
import com.ragentek.api.service.IUserService;
import com.ragentek.api.util.ApiConstants;
import com.ragentek.api.util.ApiThreadLocal;
import com.ragentek.api.util.BehaviorType;
import com.ragentek.api.util.JsonMapConverterUtil;

public class BehaviorServiceImpl extends AbstractService implements IBehaviorService {

    private static Logger logger = LogManager.getLogger(BehaviorServiceImpl.class);

    private ICommonDao dao = null;


    private IUserService userService = null;
    
    private IGroupService groupService = null;

    @Override
    public void saveBehavior(Map<String, Object> parameters) {   
        ApiThreadLocal.set(ApiConstants.CLIENT_NAME, parameters.get(ApiConstants.CLIENT_NAME));
        ApiThreadLocal.set(ApiConstants.CHANNEL_ID, parameters.get(ApiConstants.CHANNEL_ID));
        logger.debug(String.format("#################### Client post parameters for behavior analysis  [%s]", new JSONObject(parameters).toString()));

        parameters.remove(ApiConstants.LIMIT);
        parameters.remove(ApiConstants.LIMIT_KEYS);
        parameters.remove(ApiConstants.LIMIT_START);
           
        dao.add(parameters, ApiConstants.DB_LOG_COLLECTION_NAME);
        ApiThreadLocal.removeAll();

    }

    private void addBehavior(Map<String, Object> parameters){
        Object accountID  = null;



        if (accountID != null) {
            parameters.put(ApiConstants.CHENG_GAME_ACCOUNT_ID, accountID);
            Object chengyouID = parameters.get(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID);
            parameters.put(ApiConstants.CHENG_GAME_MOBILE_ID, chengyouID);
            BehaviorType type = BehaviorType.UNKNOWN;

            if (parameters.get(ApiConstants.PATH_INFO) != null) {
                type = getBehaviorTypeByPath(parameters.get(ApiConstants.PATH_INFO).toString());
            }
            
//            logger.debug(String.format("Compute user behavior start with type [%s] and path [%s]", type, parameters.get(ApiConstants.PATH_INFO)));

            if (parameters.get(ApiConstants.CHENG_GAME_BEHAVIOR_TYPE) != null) {
                type = BehaviorType.loadType(parameters.get(ApiConstants.CHENG_GAME_BEHAVIOR_TYPE));
            }

            parameters.put(ApiConstants.CHENG_GAME_BEHAVIOR_TYPE, type.toString());

            switch (type) {

            case SEARCH_APP:
                
                break;
            
            default:
//                logger.error("No behavior type found.");
                // do nothing
            }
        }else{
            logger.debug("Found user behavior whout account");
        }
        
    }

   


    private BehaviorType getBehaviorTypeByPath(String path) {
        BehaviorType type = BehaviorType.UNKNOWN;
        if ("/app/search".equals(path)) {
            type = BehaviorType.SEARCH_APP;
        } else if ("/user/search".equals(path)) {
            type = BehaviorType.SEARCH_USER;
        } else if ("/group/search".equals(path)) {
            type = BehaviorType.SEARCH_GROUP;
        } else if ("/user/view".equals(path)) {
            type = BehaviorType.USER_VIEW;
        } else if ("/user/follow".equals(path)) {
            type = BehaviorType.USER_FOLLOW;
        } else if ("/message/user/send".equals(path)) {
            type = BehaviorType.USER_MSG;
        } else if ("/app/comment/reply".equals(path)) {
            type = BehaviorType.COMMENT_REPLY;
        } else if ("/group/create".equals(path)) {
            type = BehaviorType.GROUP_CREATE;
        } else if ("/group/app/into".equals(path)) {
            type = BehaviorType.GROUP_STATION_IN_APP;
        } else if ("/group/member/fire".equals(path)) {
            type = BehaviorType.GROUP_MEMBER_FIRE;
        } else if ("/group/member/exit".equals(path)) {
            type = BehaviorType.GROUP_MEMBER_EXIT;
        } else if ("/group/member/demote".equals(path)) {
            type = BehaviorType.GROUP_USER_DEMOTED_TO_MEMBER;
        } else if ("/group/member/promote".equals(path)) {
            type = BehaviorType.GROUP_USER_PROMOTED_TO_VICE_LEADER;
        } else if ("/group/apply/pass".equals(path)) {
            type = BehaviorType.GROUP_MEMBER_JOIN_IN;
        } else if ("/usertag/bind".equals(path)) {
            type = BehaviorType.USER_BIND_TAG;
        } else if ("/post/add".equals(path)) {
            type = BehaviorType.POST_ADD;
        } else if ("/post/reply".equals(path)) {
            type = BehaviorType.POST_REPLY;
        } else if ("/post/pass".equals(path)) {
            type = BehaviorType.POST_PASSED;
        } else if ("/post/delete".equals(path)) {
            type = BehaviorType.POST_DELETE;
        }  else if ("/user/register".equals(path)) {
            type = BehaviorType.USER_REGISTER;
        } else if ("/user/info/edit".equals(path)){
        	type = BehaviorType.USER_UPDATE_INFO;
        } else if("/message/leaveword/send".equals(path)){
        	type = BehaviorType.USER_SEND_LEAVE_WORD;
        } else if("/message/group/invitation".equals(path)){
        	type = BehaviorType.GROUP_INVITE_MEMEBER;
        } else if("/group/apply/add".equals(path)){
        	type = BehaviorType.GROUP_APPLY_JOIN_GROUP;
        }  else if("/pack/client/new/get".equals(path)){
        	type = BehaviorType.PACK_VERSION_UPDATE;
        }  else if("/pack/behavior/upload".equals(path)){
        	type = BehaviorType.BATCH_BEHAVIOR_UPLOAD;
        } else if("/pack/mobile/upload".equals(path)){
        	type = BehaviorType.MOBILE_ACTIVATION;
        }

        return type;
    }

    public void saveBehavior(String jsonData) {
        Map<String, Object> map = JsonMapConverterUtil.toMap(jsonData);
		Object obj = map.get("fileBehavior");
		if (obj != null && obj instanceof Map) {
		    Map<String, Object> behavior = (Map<String, Object>) obj;
		    Object be = behavior.get("userInfos");
		    if (be != null && be instanceof ArrayList) {
		        List<Map<String, Object>> dataList = (List<Map<String, Object>>) be;
		        for (Map<String, Object> data : dataList) {
		            data.put(ApiConstants.CHENG_GAME_ACCOUNT_ANALYSIS_ID, behavior.get(ApiConstants.CHENG_GAME_ACCOUNT_ANALYSIS_ID));
		            data.put(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID, behavior.get(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID));
		            this.saveBehavior(data);
		        }
		    } else if (be != null && be instanceof Map) {
		        Map<String, Object> data = (Map<String, Object>) be;
		        data.put(ApiConstants.CHENG_GAME_ACCOUNT_ANALYSIS_ID, behavior.get(ApiConstants.CHENG_GAME_ACCOUNT_ANALYSIS_ID));
		        data.put(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID, behavior.get(ApiConstants.CHENG_GAME_MOBILE_ANALYSIS_ID));
		        this.saveBehavior(data);
		    }
		} else {
		    this.saveBehavior(JsonMapConverterUtil.toMap(jsonData));
		}
    }
  
	
    @Override
    public String geValidatorFileName() {
        return null;
    }

    public ICommonDao getDao() {
        return dao;
    }

    public void setDao(ICommonDao dao) {
        this.dao = dao;
    }

  

    public IUserService getUserService() {
        return userService;
    }

    public void setUserService(IUserService userService) {
        this.userService = userService;
    }



    public IGroupService getGroupService() {
        return groupService;
    }

    public void setGroupService(IGroupService groupService) {
        this.groupService = groupService;
    }
    
    

}
