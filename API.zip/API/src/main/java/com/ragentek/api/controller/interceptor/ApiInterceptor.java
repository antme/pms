package com.ragentek.api.controller.interceptor;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class ApiInterceptor extends HandlerInterceptorAdapter{

}
