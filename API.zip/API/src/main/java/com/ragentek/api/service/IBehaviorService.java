package com.ragentek.api.service;

import java.util.Map;

public interface IBehaviorService {

    public void saveBehavior(Map<String, Object> parameters);
    
    public void saveBehavior(String jsonData);
    
}
