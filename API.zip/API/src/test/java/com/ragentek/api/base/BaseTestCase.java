package com.ragentek.api.base;

import junit.framework.TestCase;

import org.springframework.context.ApplicationContext;

import com.ragentek.api.cfg.ConfigurationManager;
import com.ragentek.api.dao.ICommonDao;
import com.ragentek.api.dao.impl.mongo.CommonDaoMongoImpl;
import com.ragentek.api.service.IBehaviorService;
import com.ragentek.api.service.IReportService;
import com.ragentek.api.service.IUserService;
import com.ragentek.api.service.impl.UserServiceImpl;
import com.ragentek.api.util.SpringContextUtil;

public class BaseTestCase extends TestCase {

    protected static ApplicationContext ac;
    protected static ICommonDao commonDao;
    protected static IUserService userService;
    protected static IReportService reportService;
    protected static IBehaviorService behaviorService;
    public static final String TEST_ID = "123456789012345678901234";

    public BaseTestCase() {
        ac = SpringContextUtil.loadContext();
        commonDao = (CommonDaoMongoImpl) ac.getBean("commonDao");
        userService = (UserServiceImpl) ac.getBean("userService");
        reportService = (IReportService)ac.getBean("reportService");
        behaviorService = (IBehaviorService)ac.getBean("behaviorService");
        ConfigurationManager.setProperties(ConfigurationManager.DB_NAME, "ragentek_test");
    }

    public void testEmpty() {
        assertTrue(true);
    }
    
}
